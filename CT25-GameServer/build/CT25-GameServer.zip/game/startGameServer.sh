#! /bin/sh

./GameServer_loop.sh &
